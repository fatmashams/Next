import mongoose from "mongoose";


export function dbConnection() {
    mongoose.connect(
        'mongodb+srv://fatmashams818:bata20108577@cluster0.l6fq7.mongodb.net/product?retryWrites=true&w=majority&appName=Cluster0'
    ).then(
        () => { console.log('Db connection established') }

    ).catch(
        (err) => { console.log(err) }
    );
}