
const { default: mongoose } = require("mongoose");


const productSchema = mongoose.Schema(
    {
        id: { type: Number, unique: true },
        title: { type: String, required: true },
        description: { type: String, required: true },
        price: { type: Number, required: true },
        image: { type: String }
    }
)

//  {id:21, title: 'product1', description : 'GG', price : 50, image : 'https://play-lh.googleusercontent.com/_OSB1gXiLCDa8Wj1HPBvDuMuUmrs_sB_3GZ5RdgbU7Diuz905jQx1HB9tDZMj62A0xQ=w480-h960-rw' }

export const productModel = mongoose.model("Product", productSchema);