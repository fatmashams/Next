import { dbConnection } from "@/app/_lib/dbConnection";
import { productModel } from "@/app/_lib/models/product";


dbConnection();
export async function GET() {
    try {
        const request = await productModel.find();
        const products = JSON.stringify(request);
        return new Response(products, { status: 200 })
    } catch (error) {
        return new Response(JSON.stringify({ msg: `something went wrong:${error}` }))
    }
}