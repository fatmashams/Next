import React from 'react'
import { GET } from '../api/product/route'
import styles from '@/app/products/page.module.css'
import ProductCard from '@/components/productCard';


async function Product() {
    const res = await GET();
    const products =await res.json();
    console.log(products);

    return (
        <div className={styles.productsParent}>
            {products.map((prod) => (
                <div key={prod.id} className={styles.productCard}>
                    <ProductCard product={prod} />
                </div>
            ))}
        </div>
    );
};


export default Product