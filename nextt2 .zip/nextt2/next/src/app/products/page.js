import ProductCard from '@/components/productCard';
import React from 'react';
import styles from './page.module.css';

async function Product() {
    const response = await fetch('https://fakestoreapi.com/products');
    const products = await response.json();
    // console.log(products);

    return (
        <div className={styles.productsParent}>
            {products.map((prod) => (
                <div key={prod.id} className={styles.productCard}>
                    <ProductCard product={prod}/>
                </div>
            ))}
        </div>
    );
};


export default Product