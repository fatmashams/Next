import ProductCard from '@/components/productCard';
import React from 'react';


export async function generateMetadata({ params }) {
    const response = await fetch(`https://fakestoreapi.com/products/${params.id}`);
    const product = await response.json();  
    return {
      title: product.title,
    }
  }

async function ProductPage({params}) {
    const response = await fetch(`https://fakestoreapi.com/products/${params.id}`);
    const product = await response.json();
    console.log(product);
    return (
        <ProductCard product={product}/>
    )
}

export default ProductPage