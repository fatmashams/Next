"use client";

import React from "react";

function ProductCard({ product }) {
  console.log(product);

  return (
    <div className="max-w-sm rounded overflow-hidden shadow-lg">
      <img className="w-full" src={product.image} alt={product.title} />

      <div className="px-6 py-4">
        <span className="font-bold text-xl mb-2">{product.title}</span>
        <span className="font-bold text-xl mb-2">{product.price}$</span>

        <p className="text-gray-700 text-base">{product.description}</p>
        <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
          <a href={`http://localhost:3000/products/${product.id}`}>See More</a>
        </button>
      </div>
    </div>
  );
}

export default ProductCard;
