(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_products_page_b5d99dc7.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_products_page_b5d99dc7.js",
  "chunks": [
    "static/chunks/_e447ed1b._.js",
    "static/chunks/src_app_products_page_module_4e350656.css"
  ],
  "source": "dynamic"
});
