(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_not-found_5b6955.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_not-found_5b6955.js",
  "chunks": [
    "static/chunks/src_app_not-found_7ac6f5.js"
  ],
  "source": "dynamic"
});
